<?php
// Text
$_['text_title']           = 'ACH / eCheck (PlugnPay)';
$_['text_ach_echeck']      = 'Online Check Details';
$_['text_wait']            = 'Please wait!';

// Entry
$_['entry_ach_owner']       = 'Account Owner:';
$_['entry_ach_routingnum']  = 'Routing Number:';
$_['entry_ach_accountnum']  = 'Account Number:';
$_['entry_ach_checknum']    = 'Check Number:';
$_['entry_ach_accttype']    = 'Type:';
$_['entry_ach_acctclass']   = 'Class:';
?>
