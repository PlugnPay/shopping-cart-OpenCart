<?php
// Text
$_['text_title']		= 'ACH / eCheck (PlugnPay)';
$_['text_ach_echeck']		= 'Checking Account Details';

// Entry
$_['entry_accttype']		= 'Account Type';
$_['entry_accttype_checking']	= 'Checking';
$_['entry_accttype_savings']	= 'Savings';

$_['entry_acctclass']		= 'Account Classification';
$_['entry_acctclass_personal']	= 'Personal';
$_['entry_acctclass_business']	= 'Business';

$_['entry_owner']		= 'Account Owner';
$_['entry_routingnum']		= 'Routing Number';
$_['entry_accountnum']		= 'Account Number';
$_['entry_checknum']		= 'Check Number';

// Error
$_['error_owner']		= 'Account Owner Name required!';
$_['error_acctclass']		= 'Account Classification required!';
$_['error_accttype']		= 'Account Type required!';
$_['error_accountnum']		= 'Account Number must be between 1 and 19 characters!';
$_['error_routingnum']		= 'Routing Number must be between 1 and 9 characters!';
$_['error_checknum']		= 'Check Number must be between 1 and 19 characters!';
